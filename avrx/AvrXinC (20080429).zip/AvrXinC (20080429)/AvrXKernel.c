/*
 	AvrXKernel.c

   Copyright �1998 - 2002 Larry Barello (larry@barello.net)

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Library General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.

   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.

   You should have received a copy of the GNU Library General Public
   License along with this library; if not, write to the
   Free Software Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA  02111-1307, USA.

   http://www.gnu.org/copyleft/lgpl.html

   Author:  Larry Barello
            larry@barello.net

            Conversion to C by Brian Logan

   Revision History
      20051005 - Created
      20080429 - Fixed bug that caused basic tests3 and 4 to fail with
                 recent versions of WinAVR.
                 Updated Makefile to bring in line with sample Makefile
                 from WinAVR-20071221.
*/

#include <inttypes.h>
#include <avr/interrupt.h> // For cli()/sei().
#include <avr/io.h>
#include <avr/pgmspace.h>  // For pgm_read_word().
#include <avr/sfr_defs.h>  // For bit_is_clear() etc.
#include <string.h>        // For memset().

#include "AvrXC.h"

#define set_bit(var, bit) (var |= (1 << bit))
#define clear_bit(var, bit) (var &= ~(1 << bit))

// Events replace PID's in semaphores.  The kernel recognizes
// semaphore values (contents) < 0x60 as events, indexes into
// a table and calls a routine.  Macros and segments are used
// to build the table.
#define TIMERMESSAGE_EV    2
#define PERIODICTIMER_EV   3     // Not implemented.
#define _LASTEV            0x5f

/* ******* PID (Process ID) BLOCK BIT DEFINITIONS ******* */
#define IdleBit            4       /* Dead Task, don't schedule, resume or step */
#define SuspendBit         5       /* Mark task for suspension (may be blocked elsewhere) */
#define SuspendedBit       6       /* Mark task suspended (it was removed from the run queue) */
#define SingleStep         7       /* Enable single step debug support */


typedef enum _bool
{
   false,
   true
} bool;

// Function prototypes.
void TimerHandler(void);
void _SuspendScheduler(void);
void _ResumeScheduler(void) NAKED;
uint8_t _QueuePid(pProcessID pPID);
void StartTimer(pTimerControlBlock pNewTCB, uint16_t count);
void _AppendObject(void *pQueueObject, void *pObject);
void *_RemoveObject(void *pQueuedObject, void *pObject);
void *_RemoveFirstObject(void *pQueueHead);
void *_RemoveObjectAt(void *pPrevObject, void *pObject);

// Global variables.
struct _AvrXKernelData AvrXKernelData;
pTimerControlBlock _TimerQueue;
uint8_t _TimQLevel;

// Local variables.
static bool SchedulerSuspended;  // Set to true to prevent a task switch whilst performing critical actions.
                                 // Interrupts still function.





////////////////////////////////////////////////////////////////////////////////
//
// Debug functions
//
////////////////////////////////////////////////////////////////////////////////


void AvrXHalt(void)
{
	cli();
	for(;;)
      ;
}






////////////////////////////////////////////////////////////////////////////////
//
// Context switching
//
////////////////////////////////////////////////////////////////////////////////


// This function declared naked.
void Epilog(void)
{
   // Pop our return address off the stack and run _Epilog.
   asm volatile
   (
      "pop __tmp_reg__\n\t"
      "pop __tmp_reg__\n\t"
      "rjmp _Epilog"
   );
}


#define RestoreRegisters() \
   asm volatile \
   ( \
      "pop r0\n\t" \
      "out __SREG__, r0\n\t" \
      "pop r0\n\t" \
      "pop r1\n\t" \
      "pop r2\n\t" \
      "pop r3\n\t" \
      "pop r4\n\t" \
      "pop r5\n\t" \
      "pop r6\n\t" \
      "pop r7\n\t" \
      "pop r8\n\t" \
      "pop r9\n\t" \
      "pop r10\n\t" \
      "pop r11\n\t" \
      "pop r12\n\t" \
      "pop r13\n\t" \
      "pop r14\n\t" \
      "pop r15\n\t" \
      "pop r16\n\t" \
      "pop r17\n\t" \
      "pop r18\n\t" \
      "pop r19\n\t" \
      "pop r20\n\t" \
      "pop r21\n\t" \
      "pop r22\n\t" \
      "pop r23\n\t" \
      "pop r24\n\t" \
      "pop r25\n\t" \
      "pop r26\n\t" \
      "pop r27\n\t" \
      "pop r28\n\t" \
      "pop r29\n\t" \
      "pop r30\n\t" \
      "pop r31" \
   )




// This function declared naked.
void _Epilog(void)
{
   cli();

   // Only swap tasks if we're returning to user mode (AvrXKernelData.SysLevel == 0xff)
   // and scheduler is not suspended.
   if (--AvrXKernelData.SysLevel == 0xff)
   {
      // Set the running task from the head of the run queue if the scheduler is not suspended.
      if (SchedulerSuspended == false)
         AvrXKernelData.Running = AvrXKernelData.RunQueue;

      // Restore context unless task is idle task. The idle task has no context in order to save RAM space.
      if (AvrXKernelData.Running != NULL)
      {
         SP = (uintptr_t)AvrXKernelData.Running->ContextPointer;
      }
      else  // Idle "task."
      {
         for(;;)
         {
            sei();  // Enable interrupts to wake us from sleep mode on interrupt.
            asm volatile("sleep");
         }
      }
   }

   RestoreRegisters();

   asm volatile ("reti");
}

// We need to suspend the scheduler to prevent another
// task being activated during critical actions.
void _SuspendScheduler(void)
{
   uint8_t sreg = SREG;
   cli();

   SchedulerSuspended = true;

   SREG = sreg;
}


// This function declared naked.
void _ResumeScheduler(void)
{
   cli();

   SchedulerSuspended = false;

   IntProlog();
   asm volatile ("rjmp _Epilog");  // Enables interrupts on return (reti).
}






////////////////////////////////////////////////////////////////////////////////
//
// Task control
//
////////////////////////////////////////////////////////////////////////////////


void AvrXRunTask(TaskControlBlock *pTCB)
{
   AvrXResume(AvrXInitTask(pTCB));
}


// We construct an initial stack context for Epilog to use when it is called.
// The AVR stack grows downwards.
//
//    State of task stack after running AvrXInitTask:
//
//    High memory ...
//                Return address low (initialised to start address of our task)
//                Return address high (initialised to start address of our task)
//                R31
//                R30
//                R29
//
//                ...
//
//                R1
//                R0
//    Low memory  SREG
//       SP --->  ...
// 
pProcessID AvrXInitTask(TaskControlBlock *pTCB)
{
   // Get task stack pointer.
   uint8_t *pStack = (uint8_t *)pgm_read_word((uint16_t)&pTCB->StackStart);

   // Push task entry point onto stack.
   // Can't use pgm_read_word as this would give wrong byte order for start address on stack.
   // NOTE: The task start address is a WORD address, so it will only show as half the value
   // that will appear in a list produced with avr-nm -n app.elf, which is a BYTE address!!!
   *pStack-- = pgm_read_byte((uint16_t)&pTCB->start);
   *pStack-- = pgm_read_byte((uint16_t)&pTCB->start + 1);

   // Fill rest of context with zeros.
   pStack -= MINCONTEXT - 2 - 1;  // All registers + SREG, but not PC.
   memset((void *)pStack--, 0, MINCONTEXT - 2);

   pProcessID pPID = (pProcessID)pgm_read_word((uint16_t)&pTCB->pid);  // Get pointer to PID in RAM.
   pPID->ContextPointer = (void *)pStack;  // Set frame pointer.
   pPID->priority = pgm_read_byte((uint16_t)&pTCB->priority);  // Set task priority.
   pPID->flags = _BV(SuspendedBit) | _BV(SuspendBit);  // Mark state so we can "resume" PID.
   pPID->next = NULL;

   return pPID;
}


void AvrXSuspend(pProcessID pPID)
{
   _SuspendScheduler();

   pPID->flags |= _BV(SuspendBit);

   cli();

   // Remove from run queue and mark suspended if found.
   if (_RemoveObject(&AvrXKernelData.RunQueue, pPID))
      pPID->flags |= _BV(SuspendedBit);

   _ResumeScheduler();  // Interrupts enabled on return.
}


void AvrXResume(pProcessID pPID)
{
   _SuspendScheduler();

   clear_bit(pPID->flags, SuspendBit);
   if (bit_is_set(pPID->flags, SuspendedBit))
   {
      clear_bit(pPID->flags, SuspendedBit);
      _QueuePid(pPID);
   }

   _ResumeScheduler();  // Interrupts enabled on return.
}

// Removes self from run queue and re-queues. If other tasks of the
// same priority are on the queue, self will queue behind them (round robin).
void AvrXYield(void)
{
   _SuspendScheduler();

   cli();
   pProcessID pPID =
      _RemoveObject(&AvrXKernelData.RunQueue, AvrXKernelData.Running);
   sei();
   _QueuePid(pPID);

   _ResumeScheduler();  // Interrupts enabled on return.
}


uint8_t AvrXChangePriority(pProcessID pPID, uint8_t NewPriority)
{
   uint8_t OldPriority = pPID->priority;
   pPID->priority = NewPriority;

   return OldPriority;
}


pProcessID AvrXSelf(void)
{
   pProcessID RunningTask;
   uint8_t sreg = SREG;
   cli();

   RunningTask = AvrXKernelData.Running;

   SREG = sreg;

   return RunningTask;
}


uint8_t AvrXPriority(pProcessID pPID)
{
   return pPID->priority;
}






////////////////////////////////////////////////////////////////////////////////
//
// Task running
//
////////////////////////////////////////////////////////////////////////////////


// Takes a PID and inserts it into the run queue. The run queue is sorted
// by priority. Lower numbers go first. If there are multiple tasks of equal
// priority, then the new task is appended to the list of equals (round robin).
uint8_t _QueuePid(pProcessID pPID)
{
   uint8_t QueuePosition = 0, MaskedPidFlags = pPID->flags & (_BV(SuspendBit) | _BV(IdleBit));
   pProcessID pQueuedPid;

   // If marked suspended or idle...
   if (MaskedPidFlags)
   {
      pPID->flags = MaskedPidFlags | _BV(SuspendedBit);
      QueuePosition = 0xff;  // Task is suspended. Not queued.
   }
   else
   {
      pQueuedPid = (pProcessID)&AvrXKernelData.RunQueue;

      uint8_t sreg = SREG;
      cli();

      for ( ; pQueuedPid->next != NULL && pQueuedPid->next->priority <= pPID->priority; pQueuedPid = pQueuedPid->next)
      {
         ++QueuePosition;
      }

      pPID->next = pQueuedPid->next;
      pQueuedPid->next = pPID;

      SREG = sreg;
   }

   return QueuePosition;
}






////////////////////////////////////////////////////////////////////////////////
//
// Task termination
//
////////////////////////////////////////////////////////////////////////////////


void AvrXTaskExit(void)
{
   cli();
   AvrXTerminate(AvrXKernelData.Running);
}


void AvrXTerminate(pProcessID pPID)
{
   _SuspendScheduler();

   pPID->flags = _BV(IdleBit);  // Mark task dead.

   cli();
   _RemoveObject(AvrXKernelData.RunQueue, pPID);

   _ResumeScheduler();  // Interrupts enabled on return.
}






////////////////////////////////////////////////////////////////////////////////
//
// Set semaphore
//
////////////////////////////////////////////////////////////////////////////////


void AvrXSetSemaphore(pMutex pSem)
{
   _SuspendScheduler();
   AvrXIntSetSemaphore(pSem);
   _ResumeScheduler();  // Interrupts enabled on return.
}


// Return 0xff if no queueing was done.
// Return run queue position of queued PID otherwise.
uint8_t AvrXIntSetSemaphore(pMutex pSem)
{
   uint8_t sreg = SREG;
   cli();
   // Set semaphore to SEM_DONE if it is SEM_PEND or SEM_DONE.
   if (*pSem <= SEM_DONE)
      *pSem = SEM_DONE;

   // Else if semaphore is above the range for a bogus semaphore (SEM_WAIT to _LASTEV)
   // then it is really a pointer to a queue of tasks waiting on the semaphore,
   // so we remove the first PID from the queue and insert it into the run queue.
   else if (*pSem > _LASTEV)
   {
      pProcessID pTaskPid = (pProcessID)*pSem;
      _RemoveObjectAt(pSem, pTaskPid);
      SREG = sreg;
      return _QueuePid(pTaskPid);
   }

   SREG = sreg;
   return 0xff;  // Nothing queued.
}






////////////////////////////////////////////////////////////////////////////////
//
// Reset semaphore
//
////////////////////////////////////////////////////////////////////////////////


void AvrXResetSemaphore(pMutex pSem)
{
   uint8_t sreg = SREG;
   cli();

   // It doesn't make sense to reset a semaphore that
   // has a process waiting, so just skip that situation.
   if (*pSem == SEM_DONE)
      *pSem = SEM_PEND;

   SREG = sreg;
}





////////////////////////////////////////////////////////////////////////////////
//
// Test semaphore
//
////////////////////////////////////////////////////////////////////////////////


Mutex AvrXTestSemaphore(pMutex pSem)
{
   uint8_t SemState = SEM_PEND, sreg = SREG;
   cli();

   // If semaphore is SEM_DONE we return SEM_DONE
   // but reset the semaphore to SEM_PEND.
   if (*pSem == SEM_DONE)
   {
      SemState = SEM_DONE;
      *pSem = SEM_PEND;
   }

   // The semaphore greater than SEM_DONE indicates
   // tasks are queued waiting on the semaphores.
   else if (*pSem > SEM_DONE)
      SemState = SEM_WAIT;

   // The other state of SEM_PEND will return SEM_PEND.

   SREG = sreg;

   return SemState;
}


void AvrXWaitSemaphore(pMutex pSem)
{
   cli();

   if (*pSem == SEM_DONE)
   {
      *pSem = SEM_PEND;
      sei();
   }

   else
   {
      _SuspendScheduler();

      // Remove ourself from the run queue and append to the semaphore queue.
      _AppendObject(pSem, _RemoveObject(&AvrXKernelData.RunQueue, AvrXKernelData.Running));

      _ResumeScheduler();  // Interrupts enabled on return.
   }
}






////////////////////////////////////////////////////////////////////////////////
//
// Timers
//
////////////////////////////////////////////////////////////////////////////////


void AvrXDelay(pTimerControlBlock pTCB, uint16_t count)
{
   AvrXStartTimer(pTCB, count);
   AvrXWaitTimer(pTCB);
}


void AvrXStartTimer(pTimerControlBlock pNewTCB, uint16_t count)
{
   if (count == 0)
      AvrXSetSemaphore(&pNewTCB->semaphore);
   else
      StartTimer(pNewTCB, count);
}


void StartTimer(pTimerControlBlock pNewTCB, uint16_t count)
{
   _SuspendScheduler();

   AvrXResetSemaphore(&pNewTCB->semaphore);

   cli();
   --_TimQLevel;
   sei();

   // Point to first and next entries in timer queue.
   volatile pTimerControlBlock pPrevTimerQueueEntry = (pTimerControlBlock)&_TimerQueue;
   pTimerControlBlock pCurTimerQueueEntry = _TimerQueue;

   while (pPrevTimerQueueEntry->next != NULL)
   {
      if (count < pCurTimerQueueEntry->count)
      {
         pCurTimerQueueEntry->count -= count;
         break;
      }

      count -= pCurTimerQueueEntry->count;

      // Move pointers along.
      pPrevTimerQueueEntry = pCurTimerQueueEntry;
      pCurTimerQueueEntry = pCurTimerQueueEntry->next;
   }

   // Add the TCB to the timer queue.
   pPrevTimerQueueEntry->next = pNewTCB;
   pNewTCB->next = pCurTimerQueueEntry;
   pNewTCB->count = count;

   cli();
   ++_TimQLevel;

   // Handle any timer decrements we've missed whilst we've been modifying the timer queue.
   if (_TimQLevel)
      TimerHandler();  // Interrupts enabled on entry to TimerHandler().

   _ResumeScheduler();  // Interrupts enabled on return.
}


void AvrXStartTimerMessage(pTimerMessageBlock pTMB, uint16_t count, pMessageQueue pQueue)
{
   if (count == 0)
      AvrXSendMessage(pQueue, &pTMB->mcb);
   else
   {
      pTMB->queue = pQueue;
      pTMB->tcb.semaphore = TIMERMESSAGE_EV;
      StartTimer(&pTMB->tcb, count);
   }
}


pTimerControlBlock AvrXCancelTimer(pTimerControlBlock pTCB)
{
   pTimerControlBlock pRemovedTCB, pNextTCB;

   _SuspendScheduler();

   AvrXIntSetSemaphore(&pTCB->semaphore);

   cli();

   // Get a pointer to the timer following this one on the queue, if any.
   pNextTCB = pTCB->next;

   // If the TCB is in the timer queue, remove it, and add this TCB count to the next one in the queue, if any.
   if ((pRemovedTCB = _RemoveObject(&_TimerQueue, pTCB)) && pNextTCB)
      pNextTCB->count += pTCB->count;

   _ResumeScheduler();  // Interrupts enabled on return.

   return pRemovedTCB;
}


pMessageControlBlock AvrXCancelTimerMessage(pTimerMessageBlock pTMB, pMessageQueue pQueue)
{
   pTimerMessageBlock pRemovedTMB, pNextTMB;

   _SuspendScheduler();

   cli();

   // Get a pointer to the timer following this one on the queue, if any.
   pNextTMB = (pTimerMessageBlock)((pAvrXObject)pTMB)->next;

   // If the TMB is in the timer queue, remove it, and add this TMB count to the next one in the queue, if any.
   if ((pRemovedTMB = _RemoveObject(&_TimerQueue, pTMB)))
   {
      if (pNextTMB)
         pNextTMB->tcb.count += pTMB->tcb.count;
   }

   // ...else attempt to remove the message from the message queue.
   else
      pRemovedTMB = _RemoveObject(pQueue, pTMB);

   _ResumeScheduler();  // Interrupts enabled on return.

   return &pRemovedTMB->mcb;
}


void AvrXTimerHandler(void)
{
   cli();
   --_TimQLevel;

   // _TimQLevel is decremented when a task is in the process of starting a timer.
   // We only run the timer handler code if no tasks are currently starting timers and
   // if this is the first time this code has been called. Allows interrupts to be
   // enabled throughout this code.
   if (_TimQLevel == 0xff)
      TimerHandler();  // Interrupts enabled on entry to TimerHandler().
}


void TimerHandler(void)
{
   do
   {
      sei();

      // If the queue is not empty and timer has expired...
      if (_TimerQueue != NULL)
      {
         --_TimerQueue->count;

         // Deal with expired timer and any others queued after it that expire at the same time.
         while (_TimerQueue != NULL && _TimerQueue->count == 0)
         {
            // Timer expired, so remove from queue and move on to next in queue.
            pTimerControlBlock pOldTimerQueueEntry = _TimerQueue;
            _TimerQueue = _TimerQueue->next;
            pOldTimerQueueEntry->next = NULL;

            // If this is a timermessage timer, send a message to the queue, else just set the semaphore.
            if (pOldTimerQueueEntry->semaphore == TIMERMESSAGE_EV)
            {
               AvrXIntSendMessage(((pTimerMessageBlock)pOldTimerQueueEntry)->queue,
                  (pMessageControlBlock)pOldTimerQueueEntry);
            }
            else
               AvrXIntSetSemaphore(&pOldTimerQueueEntry->semaphore);
         }
      }

      cli();
      ++_TimQLevel;
   }
   while (_TimQLevel);
}


void AvrXSendMessage(pMessageQueue pQueue, pMessageControlBlock pMCB)
{
   _SuspendScheduler();
   AvrXIntSendMessage(pQueue, pMCB);
   _ResumeScheduler();  // Interrupts enabled on return.
}


void AvrXIntSendMessage(pMessageQueue pQueue, pMessageControlBlock pMCB)
{
   uint8_t sreg = SREG;
   cli();

   _AppendObject(pQueue, pMCB);
   AvrXIntSetSemaphore(&((pAvrXObject)(void *)pQueue)->semaphore);

   SREG = sreg;
}


pMessageControlBlock AvrXWaitMessage(pMessageQueue pQueue)
{
   pMessageControlBlock pQueueObject;
   cli();

   while ((pQueueObject = _RemoveFirstObject(pQueue)) == NULL)
   {
      AvrXWaitSemaphore(&((pAvrXObject)(void *)pQueue)->semaphore);
      cli();
   }

   AvrXResetSemaphore(&((pAvrXObject)(void *)pQueue)->semaphore);

   sei();

   return pQueueObject;
}


pMessageControlBlock AvrXRecvMessage(pMessageQueue pQueue)
{
   uint8_t sreg = SREG;
   cli();

   pMessageControlBlock pQueueObject = _RemoveFirstObject(pQueue);
   AvrXResetSemaphore(&((pAvrXObject)(void *)pQueue)->semaphore);

   SREG = sreg;

   return pQueueObject;
}






////////////////////////////////////////////////////////////////////////////////
//
// Queue manipulation
//
////////////////////////////////////////////////////////////////////////////////


void _AppendObject(void *pQueue, void *pObject)
{
   pAvrXObject pQ = (pAvrXObject)pQueue, pObj = (pAvrXObject)pObject;

   // Zip to end of queue.
   for ( ; pQ->next != NULL; pQ = pQ->next)
      ;

   // Append object.
   pQ->next = pObj;
   pObj->next = NULL;
}


void *_RemoveObject(void *pQueue, void *pObject)
{
   pAvrXObject pQ = (pAvrXObject)pQueue, pObj = (pAvrXObject)pObject, pRetObj = NULL;

   for ( ; pQ->next != NULL; pQ = pQ->next)
   {
      if (pQ->next == pObj)
      {
         pRetObj = _RemoveObjectAt(pQ, pObj);
         break;
      }
   }

   // Return NULL if object not found in queue, return pObject otherwise.
   return pRetObj;
}


void *_RemoveFirstObject(void *pQueue)
{
   pAvrXObject pQ = (pAvrXObject)pQueue;
   return (pQ->next == NULL) ? NULL : _RemoveObjectAt(pQ, pQ->next);
}


// Interrupts NOT disabled. Must disable if possibility of something being inserted at head of queue.
void *_RemoveObjectAt(void *pPrevObject, void *pObject)
{
   pAvrXObject pPrev = (pAvrXObject)pPrevObject, pObj = (pAvrXObject)pObject;

   pPrev->next = pObj->next;
   pObj->next = NULL;

   return pObj;
}
