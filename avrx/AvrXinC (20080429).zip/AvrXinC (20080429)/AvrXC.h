#ifndef __AVRXC_H__
#define __AVRXC_H__

/*
   AvrXC.h

   Function prototypes for AvrX C library

   Copyright �1998 - 2002 Larry Barello (larry@barello.net)

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Library General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.

   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Library General Public License for more details.

   You should have received a copy of the GNU Library General Public
   License along with this library; if not, write to the
   Free Software Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA  02111-1307, USA.

   http://www.gnu.org/copyleft/lgpl.html

   Author:  Larry Barello
            larry@barello.net

            Conversion to C by Brian Logan

   Revision History
      20051005 - Created
*/


#include <inttypes.h>
#include <stdio.h>  // For NULL.


#define FLASH      __attribute__ ((progmem))
#define EEPROM     __attribute__ ((section(".eeprom")))
#define NAKED      __attribute__ ((naked))
#define CTASK      __attribute__ ((noreturn))
#define NAKEDFUNC(A) void A(void) NAKED;\
    void A(void)
#define CTASKFUNC(A) void A(void) CTASK;\
   void A(void)

#define NOMESSAGE ((pMessageControlBlock)0)
#define NOTIMER ((pTimerControlBlock)0)
#define NOPID ((pProcessID)0)
#define SEM_PEND ((Mutex)0)
#define SEM_DONE ((Mutex)1)
#define SEM_WAIT ((Mutex)2)

#define AVRX_MUTEX(A) Mutex A
#define AVRX_MESSAGE(A) MessageControlBlock A
#define AVRX_MESSAGEQ(A) MessageQueue A
#define AVRX_TIMER(A) TimerControlBlock A

/*
    A series of macros to ease the declaration of tasks
    and access to the resulting data structures.

AVRX_TASK(start, stacksz, priority)
   Declare task data structures and forward reference to task
AVRX_TASKDEF(start, stacksz, priority)
   Declare task data structure and the top level C
   declaration (AVRX_TASK + C function declaration)
AVRX_SIGINT(vector)
   Declare the top level C declaration for an
   interrupt handler
AVRX_EXTERNTASK(start)
   Declare external task data structures
PID(start)
   Return the pointer to the task PID
TCB(start)
   Return the pointer to the task TCB
*/
#define MINCONTEXT 35           // 32 registers, return address and SREG
#define AVRX_GCC_TASK(start, c_stack, priority)  \
    char start ## Stk [c_stack + MINCONTEXT] ; \
    CTASKFUNC(start); \
    ProcessID start ## Pid; \
    TaskControlBlock start ## Tcb = \
    { \
        &start##Stk[sizeof(start##Stk)-1] , \
        start, \
        &start##Pid, \
        priority \
    }

#define AVRX_GCC_TASKDEF(start, c_stack, priority) \
    AVRX_GCC_TASK(start, c_stack, priority); \
    CTASKFUNC(start)

#define AVRX_SIGINT(vector)\
  NAKEDFUNC(vector)

#define PID(start) &start##Pid
#define TCB(start) (&start##Tcb)

#define AVRX_EXTERNTASK(start)   \
  CTASKFUNC(start);           \
  extern TaskControlBlock start##Tcb; \
  extern ProcessID start##Pid



typedef uint16_t *pMutex, Mutex;

typedef struct _AvrXObject
{
   struct _AvrXObject *next;
   Mutex semaphore;
}
* pAvrXObject, AvrXObject;

typedef struct _MessageControlBlock
{
    struct  _MessageControlBlock *next;
    Mutex   semaphore;
}
* pMessageControlBlock, MessageControlBlock;

typedef struct _ProcessID
{
   struct _ProcessID *next;
   uint8_t flags, priority;
   void *ContextPointer;
   struct _ProcessID *nextPid;  // Points to next defined PID rather than queued PID. For debugging.
}
* pProcessID, ProcessID;

typedef struct _MessageQueue
{
    pMessageControlBlock message;   /* List of messages */
    pProcessID pid;                 /* List of processes */
}
* pMessageQueue, MessageQueue;




struct _AvrXKernelData
{
   pProcessID RunQueue;
   pProcessID Running;
   void *AvrXStack;
   uint8_t SysLevel;
};

typedef struct
{
   void *StackStart;             // Start of stack (top address-1)
   void (*start) (void);         // Entry point of code
   pProcessID pid;               // Pointer to Process ID block
   uint8_t priority;             // Priority of task (0-255)
}
FLASH const TaskControlBlock;

typedef struct _TimerControlBlock
{
   struct   _TimerControlBlock *next;
   Mutex    semaphore;
   uint16_t count;
}
* pTimerControlBlock, TimerControlBlock;

typedef struct _TimerMessageBlock
{
   union
   {
      MessageControlBlock mcb;
      TimerControlBlock tcb;
   };
   MessageQueue *queue;
}
* pTimerMessageBlock, TimerMessageBlock;






#define                 AvrXAckMessage(p) AvrXSetSemaphore(&((pAvrXObject)(void *)p)->semaphore)
//void                    AvrXBreakPoint(pProcessID);
pTimerControlBlock      AvrXCancelTimer(pTimerControlBlock);
pMessageControlBlock    AvrXCancelTimerMessage(pTimerMessageBlock, pMessageQueue);
uint8_t                 AvrXChangePriority(pProcessID, uint8_t);
void                    AvrXDelay(pTimerControlBlock, uint16_t);
void                    AvrXHalt(void);
pProcessID              AvrXInitTask(TaskControlBlock *);
#define                 AvrXIntResetObjectSemaphore(pObj) AvrXResetSemaphore(&((pAvrXObject)(void *)pObj)->semaphore)
#define                 AvrXIntResetSemaphore(pSem) AvrXResetSemaphore(pSem)
void                    AvrXIntSendMessage(pMessageQueue, pMessageControlBlock);
uint8_t                 AvrXIntSetSemaphore(pMutex);
#define                 AvrXIntTestSemaphore(p) AvrXTestSemaphore(p)
uint8_t                 AvrXPriority(pProcessID);
pMessageControlBlock    AvrXRecvMessage(pMessageQueue);
void                    AvrXResetSemaphore(pMutex);
void                    AvrXResume(pProcessID);
void                    AvrXRunTask(TaskControlBlock *);
pProcessID              AvrXSelf(void);
void                    AvrXSendMessage(pMessageQueue, pMessageControlBlock);
#define                 AvrXSetKernelStack(bval) \
   (AvrXKernelData.AvrXStack = (void *)(((void *)bval == NULL) ? (void *)SP : (void *)bval))
void                    AvrXSetSemaphore(pMutex);
//uint8_t                 AvrXSingleStep(pProcessID);
//uint8_t                 AvrXSingleStepNext(pProcessID);
#define                 AvrXStartScheduler() Epilog()
void                    AvrXStartTimer(pTimerControlBlock, uint16_t);
void                    AvrXStartTimerMessage(pTimerMessageBlock timer, uint16_t timeout, pMessageQueue queue);
void                    AvrXSuspend(pProcessID);
void                    AvrXTaskExit(void);
void                    AvrXTerminate(pProcessID);
#define                 AvrXTestMessageAck(p) AvrXTestSemaphore(&((pAvrXObject)(void *)p)->semaphore)
#define                 AvrXTestPid(p) AvrXTestSemaphore(&((pAvrXObject)(void *)p)->semaphore)
Mutex                   AvrXTestSemaphore(pMutex);
#define                 AvrXTestTimer(p) AvrXTestSemaphore(&((pAvrXObject)(void *)p)->semaphore)
void                    AvrXTimerHandler(void);
pMessageControlBlock    AvrXWaitMessage(pMessageQueue);
#define                 AvrXWaitMessageAck(pObj) AvrXWaitSemaphore(&((pAvrXObject)(void *)pObj)->semaphore)
void                    AvrXWaitSemaphore(pMutex);
#define                 AvrXWaitTask(pObj) AvrXWaitSemaphore(&((pAvrXObject)(void *)pObj)->semaphore)
#define                 AvrXWaitTimer(pObj) AvrXWaitSemaphore(&((pAvrXObject)(void *)pObj)->semaphore)
void                    AvrXYield(void);
void                    _Epilog(void) NAKED;    // Not to be used for C code
void                    Epilog(void) NAKED;
void                    IntProlog(void);


extern struct _AvrXKernelData AvrXKernelData;

#endif
